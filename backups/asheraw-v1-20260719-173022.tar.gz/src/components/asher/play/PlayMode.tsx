"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { GameCanvas, ZONE_LABELS } from "./GameCanvas";
import { PlaySections } from "./PlaySections";
import { track } from "@/lib/analytics";

export function PlayMode() {
  const [activeSection, setActiveSection] = useState<string>("hero");
  const contentRef = useRef<HTMLDivElement>(null);
  const gamePanelRef = useRef<HTMLDivElement>(null);
  const [panelHeight, setPanelHeight] = useState<number | null>(null);
  const isProgrammaticScroll = useRef(false);

  // Measure the game panel height and apply it to the content panel
  // so both columns are the same height — no page bouncing.
  useEffect(() => {
    const measure = () => {
      if (gamePanelRef.current) {
        const h = gamePanelRef.current.offsetHeight;
        setPanelHeight(h);
      }
    };
    measure();
    window.addEventListener("resize", measure);
    // Re-measure after fonts/images load
    const t = setTimeout(measure, 300);
    return () => {
      window.removeEventListener("resize", measure);
      clearTimeout(t);
    };
  }, []);

  useEffect(() => {
    const root = contentRef.current;
    if (!root) return;
    const observer = new IntersectionObserver((entries) => {
        if (isProgrammaticScroll.current) return;
        let best: { id: string; ratio: number } | null = null;
        entries.forEach((e) => { const el = e.target as HTMLElement; const id = el.dataset.sectionId; if (!id) return; if (!best || e.intersectionRatio > best.ratio) best = { id, ratio: e.intersectionRatio }; });
        if (best && best.ratio > 0.25) setActiveSection((prev) => (prev !== best!.id ? best!.id : prev));
      }, { root, threshold: [0.25, 0.5, 0.75] });
    root.querySelectorAll("[data-section-id]").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleZoneEnter = useCallback((zoneId: string) => {
    const root = contentRef.current; if (!root) return;
    const el = root.querySelector(`[data-section-id="${zoneId}"]`); if (!el) return;
    isProgrammaticScroll.current = true;
    // Manually set scrollTop on the content panel only — NOT scrollIntoView,
    // which would also scroll the window and cause the whole page to jump.
    const target = el as HTMLElement;
    const offset = target.offsetTop;
    root.scrollTo({ top: offset, behavior: "smooth" });
    setActiveSection(zoneId);
    track({ action: "play_zone_enter", category: "play", label: zoneId });
    window.setTimeout(() => { isProgrammaticScroll.current = false; }, 900);
  }, []);

  const currentZoneInfo = ZONE_LABELS[activeSection] || ZONE_LABELS.hero;

  return (
    <div className="px-4 pt-24 pb-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1500px]">
        <div className="mb-6 text-center">
          <p className="font-mono-stage text-xs uppercase tracking-[0.32em] text-spotlight/80">/ play_mode · interactive</p>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight tracking-[-0.02em] text-ivory sm:text-5xl lg:text-6xl">Walk Asher through <span className="italic text-spotlight-gradient">his world.</span></h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-stone/80">Use arrow keys, WASD, or click a zone to move Asher. When he steps into a zone, the info on the right updates. Or scroll the panel — Asher will walk to that section and start a related activity.</p>
        </div>
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:items-start">
          {/* Game panel — measured to set content panel height */}
          <div ref={gamePanelRef} className="lg:sticky lg:top-20">
            <div className="rounded-2xl border border-amber-faint bg-stage/40 p-3 sm:p-4">
              <GameCanvas activeSection={activeSection} onZoneEnter={handleZoneEnter} />
              <div className="mt-3 flex items-center justify-between rounded-xl border border-amber-faint/60 bg-stage/60 px-4 py-2.5">
                <div className="flex items-center gap-2"><span className="h-2 w-2 animate-soft-blink rounded-full bg-spotlight" /><span className="font-mono-stage text-xs uppercase tracking-[0.2em] text-stone/70">Currently in</span><span className="font-display text-base font-semibold text-spotlight">{currentZoneInfo.label}</span></div>
                <span className="font-mono-stage text-xs uppercase tracking-[0.18em] text-stone/60">{currentZoneInfo.activity}</span>
              </div>
            </div>
          </div>
          {/* Content panel — exactly the same height as the game panel.
              Scrolls internally so the page doesn't bounce.
              overscroll-contain prevents scroll from chaining to the page
              when the user reaches the top/bottom of the panel. */}
          <div
            ref={contentRef}
            className="rounded-2xl border border-amber-faint bg-stage/30 overflow-y-auto scrollbar-thin-amber overscroll-contain"
            style={panelHeight ? { height: `${panelHeight}px` } : undefined}
          >
            <PlaySections />
          </div>
        </div>
      </div>
    </div>
  );
}
